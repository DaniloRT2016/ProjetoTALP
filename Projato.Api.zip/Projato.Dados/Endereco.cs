namespace Projato.Dados
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Endereco")]
    public partial class Endereco
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Endereco()
        {
            Orcamento = new HashSet<Orcamento>();
        }

        [Key]
        public int IdEndereco { get; set; }

        [StringLength(120)]
        public string DescricaoEndereco { get; set; }

        [StringLength(60)]
        public string ComplementoEndereco { get; set; }

        [StringLength(8)]
        public string CepEndereco { get; set; }

        [StringLength(60)]
        public string BairroEndereco { get; set; }

        public int? Pessoa_FisicaIdPessoaFisica { get; set; }

        public int? Pessoa_JuridicaIdPessoaJuridica { get; set; }

        public virtual Pessoa_Fisica Pessoa_Fisica { get; set; }

        public virtual Pessoa_Juridica Pessoa_Juridica { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Orcamento> Orcamento { get; set; }
    }
}
