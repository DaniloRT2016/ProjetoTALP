namespace Projato.Dados
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Tipo_Avaliacao
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Tipo_Avaliacao()
        {
            Solicitacao_Orcamento = new HashSet<Solicitacao_Orcamento>();
        }

        [Key]
        public int IdAvaliacao { get; set; }

        [Required]
        [StringLength(60)]
        public string DescricaoAvaliacao { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Solicitacao_Orcamento> Solicitacao_Orcamento { get; set; }
    }
}
