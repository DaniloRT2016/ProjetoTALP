namespace Projato.Dados
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Orcamento")]
    public partial class Orcamento
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdOrcamento { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(50)]
        public string QuantidadeOrcamento { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(50)]
        public string ValorOrcamento { get; set; }

        public int? EnderecoIdEndereco { get; set; }

        public virtual Endereco Endereco { get; set; }
    }
}
