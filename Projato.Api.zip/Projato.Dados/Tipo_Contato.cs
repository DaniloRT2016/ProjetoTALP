namespace Projato.Dados
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Tipo_Contato
    {
        [Key]
        public int IdTipoContato { get; set; }

        [Required]
        [StringLength(45)]
        public string DescricaoContato { get; set; }
    }
}
