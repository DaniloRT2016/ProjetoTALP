namespace Projato.Dados
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Configuracao_Agenda
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Configuracao_Agenda()
        {
            Solicitacao_Orcamento = new HashSet<Solicitacao_Orcamento>();
        }

        [Key]
        public int IdConfiguracao { get; set; }

        public int Dia_Semana { get; set; }

        public int QuantidadeHora { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Solicitacao_Orcamento> Solicitacao_Orcamento { get; set; }
    }
}
