namespace Projato.Dados
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<Categoria> Categoria { get; set; }
        public virtual DbSet<Configuracao_Agenda> Configuracao_Agenda { get; set; }
        public virtual DbSet<Contato> Contato { get; set; }
        public virtual DbSet<Endereco> Endereco { get; set; }
        public virtual DbSet<Login> Login { get; set; }
        public virtual DbSet<Perfil_Acesso> Perfil_Acesso { get; set; }
        public virtual DbSet<Pessoa_Fisica> Pessoa_Fisica { get; set; }
        public virtual DbSet<Pessoa_Juridica> Pessoa_Juridica { get; set; }
        public virtual DbSet<Produto> Produto { get; set; }
        public virtual DbSet<Solicitacao_Orcamento> Solicitacao_Orcamento { get; set; }
        public virtual DbSet<sysdiagrams> sysdiagrams { get; set; }
        public virtual DbSet<Tipo_Avaliacao> Tipo_Avaliacao { get; set; }
        public virtual DbSet<Tipo_Contato> Tipo_Contato { get; set; }
        public virtual DbSet<Tipo_Status_Orcamento> Tipo_Status_Orcamento { get; set; }
        public virtual DbSet<Orcamento> Orcamento { get; set; }
        public virtual DbSet<Orcamento_Has_Produto> Orcamento_Has_Produto { get; set; }
        public virtual DbSet<Venda> Venda { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Categoria>()
                .Property(e => e.DescricaoCategoria)
                .IsUnicode(false);

            

            //modelBuilder.Entity<Categoria>()
            //    .HasMany(e => e.Produto)
            //    .WithRequired(e => e.Categoria)
            //    .WillCascadeOnDelete(false);

            modelBuilder.Entity<Configuracao_Agenda>()
                .HasMany(e => e.Solicitacao_Orcamento)
                .WithOptional(e => e.Configuracao_Agenda)
                .HasForeignKey(e => e.Configuracao_Agenda_IdConfiguracao);

            modelBuilder.Entity<Endereco>()
                .Property(e => e.DescricaoEndereco)
                .IsUnicode(false);

            modelBuilder.Entity<Endereco>()
                .Property(e => e.ComplementoEndereco)
                .IsUnicode(false);

            modelBuilder.Entity<Endereco>()
                .Property(e => e.CepEndereco)
                .IsUnicode(false);

            modelBuilder.Entity<Endereco>()
                .Property(e => e.BairroEndereco)
                .IsUnicode(false);

            modelBuilder.Entity<Login>()
                .Property(e => e.EmailLogin)
                .IsUnicode(false);

            modelBuilder.Entity<Login>()
                .Property(e => e.SenhaLogin)
                .IsUnicode(false);

            modelBuilder.Entity<Login>()
                .Property(e => e.IdSocial)
                .IsUnicode(false);

            modelBuilder.Entity<Login>()
                .Property(e => e.NomeLogin)
                .IsUnicode(false);

            modelBuilder.Entity<Login>()
                .HasMany(e => e.Perfil_Acesso)
                .WithMany(e => e.Login)
                .Map(m => m.ToTable("Login_Perfil_Acesso").MapLeftKey("LoginIdLogin").MapRightKey("Perfil_AcessoIdPerfilAcesso"));

            modelBuilder.Entity<Perfil_Acesso>()
                .Property(e => e.DescricaoAcesso)
                .IsUnicode(false);

            modelBuilder.Entity<Pessoa_Fisica>()
                .Property(e => e.PessoaFisicaCpf)
                .IsUnicode(false);

            modelBuilder.Entity<Pessoa_Juridica>()
                .Property(e => e.CnpjPessoaJuridica)
                .IsFixedLength();

            modelBuilder.Entity<Pessoa_Juridica>()
                .Property(e => e.NomeFantasiaPessoaJuridica)
                .IsUnicode(false);

            modelBuilder.Entity<Produto>()
                .Property(e => e.NomeProduto)
                .IsUnicode(false);

            modelBuilder.Entity<Produto>()
                .Property(e => e.DescricaoProduto)
                .IsUnicode(false);

            modelBuilder.Entity<Produto>()
                .Property(e => e.IndicadorVitrine)
                .IsUnicode(false);

            modelBuilder.Entity<Tipo_Avaliacao>()
                .Property(e => e.DescricaoAvaliacao)
                .IsUnicode(false);

            modelBuilder.Entity<Tipo_Avaliacao>()
                .HasMany(e => e.Solicitacao_Orcamento)
                .WithOptional(e => e.Tipo_Avaliacao)
                .HasForeignKey(e => e.Tipo_Avaliacao_IdAvaliacao);

            modelBuilder.Entity<Tipo_Contato>()
                .Property(e => e.DescricaoContato)
                .IsUnicode(false);

            modelBuilder.Entity<Tipo_Status_Orcamento>()
                .Property(e => e.DescricaoStatusOrcamento)
                .IsUnicode(false);

            modelBuilder.Entity<Tipo_Status_Orcamento>()
                .HasMany(e => e.Solicitacao_Orcamento)
                .WithRequired(e => e.Tipo_Status_Orcamento)
                .HasForeignKey(e => e.Tipo_Status_Orcamento_IdStatus)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Orcamento>()
                .Property(e => e.QuantidadeOrcamento)
                .IsUnicode(false);

            modelBuilder.Entity<Orcamento>()
                .Property(e => e.ValorOrcamento)
                .IsUnicode(false);

         
        }
    }
}
