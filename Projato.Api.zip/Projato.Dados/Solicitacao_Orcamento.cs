namespace Projato.Dados
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Solicitacao_Orcamento
    {
        [Key]
        public int IdSolicitacaoOrcamento { get; set; }

        public int LoginIdCliente { get; set; }

        public int? LoginIdTecnico { get; set; }

        [Column(TypeName = "date")]
        public DateTime DataSolicitacaoOrcamento { get; set; }

        public int Tipo_Status_Orcamento_IdStatus { get; set; }

        public int? Tipo_Avaliacao_IdAvaliacao { get; set; }

        public int? Configuracao_Agenda_IdConfiguracao { get; set; }

        public int EnderecoIdEndereco { get; set; }

        public virtual Configuracao_Agenda Configuracao_Agenda { get; set; }

        public virtual Tipo_Avaliacao Tipo_Avaliacao { get; set; }

        public virtual Tipo_Status_Orcamento Tipo_Status_Orcamento { get; set; }
    }
}
