namespace Projato.Dados
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Pessoa_Fisica
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Pessoa_Fisica()
        {
            Endereco = new HashSet<Endereco>();
        }

        [Key]
        public int IdPessoaFisica { get; set; }

        [Required]
        [StringLength(11)]
        public string PessoaFisicaCpf { get; set; }

        [Column(TypeName = "date")]
        public DateTime DataNascPessoaFisica { get; set; }

        public int LoginIdLogin { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Endereco> Endereco { get; set; }
    }
}
